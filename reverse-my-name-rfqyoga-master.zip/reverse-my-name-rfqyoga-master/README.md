# Reverse my Name

Given a name, try to reverse all characters in the name

```
INPUT -> Michael Jackson
Output-> noskcaJ leahciM

```